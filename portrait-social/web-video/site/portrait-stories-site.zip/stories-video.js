'use strict';
/* Short 4:5 story videos (Mama, Papa). Language follows the site's DE/CS/RU switch.
   Playback is always started by the visitor; only one video plays at a time. */
(() => {
  const players = [...document.querySelectorAll('video[data-story]')];
  if (!players.length) return;
  const languages = ['de', 'cs', 'ru'];
  const base = 'assets/media/stories/';
  // Browser translation can rewrite html.lang; the pressed language button stays authoritative.
  const language = () => {
    const picked = document.querySelector('[data-lang][aria-pressed="true"]')?.dataset.lang || document.documentElement.lang;
    return languages.includes(picked) ? picked : 'de';
  };
  let current = '';
  function apply() {
    const lang = language();
    if (lang === current) return;
    current = lang;
    players.forEach(video => {
      const name = video.dataset.story;
      const source = video.querySelector('source');
      const src = `${base}${name}-${lang}.mp4`;
      if (source.getAttribute('src') === src) return;
      video.pause();
      video.poster = `${base}${name}-${lang}-poster.webp`;
      source.setAttribute('src', src);
      video.load();
    });
  }
  apply();
  new MutationObserver(apply).observe(document.documentElement, {attributes: true, attributeFilter: ['lang']});
  document.querySelectorAll('[data-lang]').forEach(button => button.addEventListener('click', () => setTimeout(apply, 0)));
  document.addEventListener('visibilitychange', () => { if (document.hidden) players.forEach(video => video.pause()); });
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (!entry.isIntersecting) entry.target.pause(); }), {threshold: 0});
    players.forEach(video => observer.observe(video));
  }
  const all = [...players, document.getElementById('portraitVideo')].filter(Boolean);
  all.forEach(video => video.addEventListener('play', () => all.forEach(other => { if (other !== video) other.pause(); })));
})();
